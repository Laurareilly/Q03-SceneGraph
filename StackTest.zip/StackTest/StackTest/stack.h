#ifndef STACK_H
#define STACK_H

#include <exception>
#include <iostream>
#include "4x4Transformation.h"
#include "3x3Matrix.h"

template <class T> 
class Stack
{
public:
	struct Node
	{
		T mData;
		Node* mChild; //the way i made this stack, the each node's child is above them
		
		Node() {};
		~Node() {};
		Node(T data)
		{
			mData = data;
			mChild = nullptr;
		}
	};

	Stack();
	~Stack();

	T findValueFromIndex(int index); //returns the int value at a given index
	bool isValueInStack(T value); //returns true if a given value exists in the stack
	T multiplyValuesInStack();
	int getSize() { return mSize; }
	T pop();
	void push(T data);

private:
	Node* mTop, *mBottom;
	int mSize;
};


template <typename T> 
Stack<T>::Stack()
{
	mSize = 0;
	mTop = nullptr;
	mBottom = nullptr;
}

template <typename T>
Stack<T>::~Stack()
{
	mTop = nullptr;
	mBottom = nullptr;
}

//returns the int value at a given index
template <typename T>
T Stack<T>::findValueFromIndex(int index)
{
	if (index < 0 || index > mSize + 1)
	{
		std::cerr << "Error! Index given is greater than stack bounds. Returning -1.\n";
		return T();
	}

	Node* ptr;
	ptr = mBottom;

	for (int i = 0; i < index; i++)
	{
		ptr = ptr->mChild;
	}
	return ptr->mData;
}

//returns true if a given value exists in the stack
template <typename T>
bool Stack<T>::isValueInStack(T value)
{
	Node* ptr;
	ptr = mBottom;

	if (mSize == 0)
	{
		return false;
	}

	for (int i = 0; i < mSize; i++)
	{
		if (ptr->mData == value)
		{
			return true;
		}
		ptr = ptr->mChild;
	}

	return false;
}

template<class T>
T Stack<T>::multiplyValuesInStack()
{
	Node* ptr = mBottom;
	T tempData;

	if (mBottom == nullptr)
	{
		return T{ 0 };
	}

	tempData = mBottom->mData;

	if (mTop == mBottom)
	{
		return tempData;
	}

	while (ptr->mChild != nullptr)
	{
		tempData = ptr->mChild->mData * tempData;
		ptr = ptr->mChild;
	}

	return tempData;
}

template <typename T>
void Stack<T>::push(T data)
{
	Node* ptr;
	ptr = new Node(data);

	if (mBottom == nullptr) //if the stack is empty, what we added is both the bottom and the top
	{
		mBottom = ptr;
		mTop = ptr;
	}
	else
	{
		mTop->mChild = ptr; //take what's at the top, and make what we added above it
		mTop = ptr;
	}
	mSize++;
}

template <typename T>
T Stack<T>::pop()
{
	Node* temp, *previous, *toBePopped;
	temp = mBottom;

	if (mSize == 0)
	{
		std::cerr << "Error! You are trying to remove an element from an empty stack. The size remains zero.\n";
		return 0;
	}

	if (mBottom == mTop)
	{
		temp = mBottom;
		mBottom = nullptr;
		mTop = nullptr;
		mSize--;
		return temp->mData;
	}
	else
	{
		toBePopped = mTop;
		while (temp != mTop)
		{
			previous = temp;
			temp = temp->mChild;
		}
		mSize--;
		return toBePopped->mData;
		mTop = previous;
	}
}





#endif

