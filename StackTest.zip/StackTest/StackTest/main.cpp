#include <iostream>
#include "stack.h"
#include "4x4Transformation.h"
#include "3x3Matrix.h"

using namespace std;

int main()
{
	Transform4x4 matrix1 = { 0 };
	Mat3x3 matrix2 = makeRotX(1);
	Mat3x3 matrix3 = makeRotY(1);
	Mat3x3 matrix4 = makeRotZ(1);

	Stack<int> integerStack;
	Stack<Transform4x4> matrix4x4Stack;
	Stack<Mat3x3> matrix3x3Stack;

	matrix4x4Stack.push(matrix1);
	cout << "There is " << matrix4x4Stack.getSize() << " matrix in the stack\n";

	matrix3x3Stack.push(matrix2);
	matrix3x3Stack.push(matrix3);
	matrix3x3Stack.push(matrix4);


	cout << "There is " << matrix3x3Stack.getSize() << " matrix in the stack\n";

	matrix3x3Stack.multiplyValuesInStack();

	/*
	cout << "The size of the stack is " << integerStack.getSize() << endl;;
	integerStack.push(0);
	integerStack.push(10);
	integerStack.push(25);
	integerStack.push(154);
	cout << "The size of the stack is " << integerStack.getSize() << endl;;
	*/

	//cout << "The value at the given index is " << integerStack.findValueFromIndex(0) << endl;
	
	//if (integerStack.isValueInStack(1000))
	//{
	//	cout << "ya that value is in the stack\n";
	//}
	//else
	//{
	//	cout << "why would you even think that value is in the stack\n";
	//}

	//cout << "The size of the stack is " << integerStack.getSize() << endl;
	//integerStack.pop();
	//integerStack.pop();
	//integerStack.pop();

	cin.get();
	cin.ignore();
	return 0;
}